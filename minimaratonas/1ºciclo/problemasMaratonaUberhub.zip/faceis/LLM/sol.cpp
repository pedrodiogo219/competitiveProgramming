#include <iostream>

using namespace std;

int main() {
	int x, r1, r2;
	cin >> r1 >> r2;
	x = ((r1*12)-(r2*3))/3;
	cout << "Lightning Little Marcos:\n\n\n";
	cout << r1+r2 << ".0 -> " << x << endl;
	return 0;
}