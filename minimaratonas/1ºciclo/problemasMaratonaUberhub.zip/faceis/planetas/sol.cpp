#include <stdio.h>

int main() {
    int combustivel, planetas;
    scanf("%d", &combustivel);
    planetas = combustivel/18;
    printf ("Numero maximo de planetas: %d\n", planetas);
}
